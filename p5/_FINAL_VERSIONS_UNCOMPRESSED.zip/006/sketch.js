/*
----------------------------------------------------------------

----------------------------------------------------------------
*/

let t = 0.0;
let pg, pg2;
let recording = false;

//SYSTEM
let runners = null;

//CREATIVE MODE
let creativeMode = false;

///////FINAL
let palette = [
    ['#CBFF00', '#0000FF'],
    ['#CBFF00', '#006200'],
    ['#CBFF00', '#FF0000'],
    ['#CBFF00', '#5d5d5d'],
    ['#CBFF00', '#772ABC'],
    ['#772ABC', '#FF0000'],
    ['#772ABC', '#5d5d5d'],
    ['#FF0000', '#006200'],
    ['#0000FF', '#006200'],
    ['#00FF00', '#006200'],
    ['#00FF00', '#000000'],
    ['#FF0000', '#000000'],
    ['#CBFF00', '#000000'],
    ['#FFFFFF', '#000000'],
    ['#590000', '#FF0000'],
    ['#006200', '#CBFF00', '#FF0000'],
    ['#006200', '#CBFF00', '#0000FF'],
    ['#FF0000', '#5d5d5d', '#772ABC'],
    ['#FF0000', '#CBFF00', '#0000FF'],
    ['#5d5d5d', '#FF0000', '#772ABC'],
    ['#5d5d5d', '#0000FF', '#CBFF00'],
    ['#5d5d5d', '#00FF00', '#006200'],
    ['#FF0000', '#00FF00', '#0000FF', '#000000'],
    ['#006200', '#CBFF00', '#FF0000', '#772ABC'],
    ['#006200', '#CBFF00', '#FF0000', '#5d5d5d'],
    ['#006200', '#CBFF00', '#772ABC', '#5d5d5d'],
    ['#0000FF', '#FF0000', '#00FF00', '#000000'],
    ['#0000FF', '#006200', '#CBFF00', '#5d5d5d'],
    ['#0000FF', '#FF0000', '#006200', '#CBFF00', '#5d5d5d', '#772ABC'],
    ['#0000FF', '#FF0000', '#006200', '#CBFF00', '#5d5d5d', '#772ABC']];



let palette1, palette2;
let palettePicker;

let seed;
let colorPicker, colorPicker2;
let numSystems, numSystems2;
let columnsRandom;

let sizeQuad;
let colorQuads;
let randShapes;
let sizeCx, sizeCy;

let finalImage, finalImage2, tempPixels, tempPixels2;

/////RESOLUTION
let r1, r2;
let tex;
let canvas;

let seeds = [
            [251, 10, 155] // 6
            ]

let seedCount = 0;
let seedIndex = 0;

////PAUSE PLAY
let running = true;


function setup() {
    start(seeds[0][0]);
}

function draw() {

    ////IF NOT PAUSED
    if(running == true){

        ///////ROTATE THE SEED
        if(t>1 && t%300==0){
            ///ADDS TO SEED COUNT
            if(seedCount<2){
                seedCount++;
            }else{
                seedCount = 0;
            }

            start(seeds[seedIndex][int(seedCount)]);
        }


        background(0, 0, 0);
        pgShow();

        ///SECOND IMAGE
        finalImage.loadPixels();

        //////NON-UPSCALE
        for(let x=0; x<finalImage.width; x++){
            for(let y=0; y<finalImage.height; y++){
                let tempIndex = (x + y * finalImage.width)*4;

                finalImage.pixels[tempIndex] = tempPixels[tempIndex];
                finalImage.pixels[tempIndex+1] = tempPixels[tempIndex+1];
                finalImage.pixels[tempIndex+2] = tempPixels[tempIndex+2];
                finalImage.pixels[tempIndex+3] = tempPixels[tempIndex+3];

            }
        }

        finalImage.updatePixels();


        ///SECOND IMAGE
        finalImage2.loadPixels();

        //////NON-UPSCALE
        for(let x=0; x<finalImage2.width; x++){
            for(let y=0; y<finalImage2.height; y++){

                let tempIndex = (x + y * finalImage2.width)*4;

                finalImage2.pixels[tempIndex] = tempPixels2[tempIndex];
                finalImage2.pixels[tempIndex+1] = tempPixels2[tempIndex+1];
                finalImage2.pixels[tempIndex+2] = tempPixels2[tempIndex+2];
                finalImage2.pixels[tempIndex+3] = tempPixels2[tempIndex+3];

            }
        }

        finalImage2.updatePixels();
        
        imageMode(CENTER);
        image(finalImage, windowWidth/2, windowHeight/2, windowWidth / windowHeight > 1.98 ? windowWidth : windowHeight*1.98, windowWidth / windowHeight > 1.98 ? windowWidth * 0.50 : windowHeight);
        image(finalImage2, windowWidth/2, windowHeight/2, windowWidth / windowHeight > 1.98 ? windowWidth : windowHeight*1.98, windowWidth / windowHeight > 1.98 ? windowWidth * 0.50 : windowHeight);

    } /////IF RUNNING

}

function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}



function pgShow(){
    t++;

    //BEGIN
    pg.background(0);


    //SYSTEMS
    if(t==1){
        for(let i=0; i<numSystems; i++){
            runners.push(new ParticleSystem(floor(random(2,7)), random(3,5), palette1[i], i, pg, pg.width, pg.height, 1));
        }
    }

    if(t==1){
        for(let i=0; i<numSystems2; i++){
            runners.push(new ParticleSystem(floor(random(4,7)), random(1.5,2), palette2[i], i, pg, pg.width, pg.height, 2));
        }
    }


    //RUN SYSTEMS
    for(let i=0; i<runners.length; i++){
        let p = runners[i];
        p.force();
        p.nu();
        p.update();
    }

    //    MASK SIZE
    let p = runners[0];
    sizeCx = p.stepSize/2*columnsRandom;
    sizeCy = pg.height/2;


}


function start(finalSeed){
    canvas = createCanvas(windowWidth, windowHeight);
    frameRate(30);

    t = 0.0;
    frameCount = 0;

    noCursor();
    noiseSeed(4);
    strokeWeight(1.01);
    //SEED
    seed = floor(random(random(12222,1222111)));//finalSeed;//floor(random(random(1000000)));
    
    if(creativeMode==true){
        randomSeed(seed);
    }else{
        randomSeed(finalSeed);
    }
    
    //RESOLUTION
    r1 = 10;
    r2 = 10;

    ///START SYSTEM
    runners = [];



    ///PG1
    numSystems = floor(random(2,4));    
    let pgX = int(2560/r1/2*2+1);
    let pgY = int(1290/r1/2*2+1);
    pg = createGraphics(pgX, pgY);
    pg.pixelDensity(1);

    ///SYSTEMS 2
    numSystems2 = floor(random(2,5));


    canvas.imageSmoothingEnabled = false;
    p5.disableFriendlyErrors = true;
    noSmooth();

    ///RANDSHAPES
    randShapes = random(10);

    let fIx = int(2560/r1/2*2+1);
    let fIy = int(1290/r1/2*2+1);

    let fIx2 = int(2560/r2/2*2+1);
    let fIy2 = int(1290/r2/2*2+1);

    //FINALIMAGE AND TEMP ARRAY OF PIXELS
    finalImage = createImage(fIx, fIy);
    finalImage2 = createImage(fIx2, fIy2);

    tempPixels = [];
    tempPixels2 = [];
    pixelDensity(1);

    ///PALETTES
    palette1 = [];
    palette2 = [];

    palettePicker = floor(map(random(1), 0, 1, 0, palette.length));

    for(let i=0; i<numSystems; i++){
        colorPicker = floor(map(random(1), 0, 1, 0, palette[palettePicker].length));
        let finalCol = color(palette[palettePicker][colorPicker]);
        palette1[i] = finalCol;
    }

    for(let i=0; i<numSystems2; i++){
        colorPicker = floor(map(random(1), 0, 1, 0, palette[palettePicker].length));
        let finalCol = color(palette[palettePicker][colorPicker]);
        palette2[i] = finalCol;
    }

    ////RANDOM NUM OF COLUMNS
    columnsRandom = floor(random(1, 5));

    console.log('gämma: live');
    console.log('number of systems: ' + numSystems + '/' + numSystems2);
    console.log('current seed: ' + seed);
}




/*
----------------------------------------------------------------
SYSTEM
----------------------------------------------------------------
*/


let ParticleSystem = function(tempColumns, tempInitialVel, tempCor, tempIndex, tempPg, tempW, tempH, layer) {
    this.particles = [];

    this.loc = createVector(0.0, -4.0);
    this.vel = createVector(0.0, 0.0);
    this.acc = createVector(0.0, 0.0);
    
    this.lifespan = 160.0;
    
    this.columns = tempColumns;
    this.initialVel = tempInitialVel;
    this.cor = tempCor;
    
    this.stepToMiss = 2;
    this.index = tempIndex;
    this.intervalCells = random(0, 5);
    
    this.finalPg = tempPg;
    this.w = tempW;
    this.h = tempH;
    
    this.stepSize = this.w/this.columns;
    this.layer = layer;
};


ParticleSystem.prototype.update = function() {
    this.lifespan -= 2.0;
    
    
    let len = this.particles.length;

    for (let i = len - 1; i >= 0; i--) {
        let particle = this.particles[i];
        particle.update();
        particle.display();

        if (particle.isDead()) {
            this.particles.splice(i, 1);
        }
        
    }
}

ParticleSystem.prototype.isDead = function () {
    if (this.lifespan <= 0.0) {
        return true;
    } else {
        return false;
    }
}


ParticleSystem.prototype.force = function () {
    this.cent = createVector(0.0, this.h);
    this.p = p5.Vector.sub(this.cent, this.loc);
    
    this.p.normalize();
    this.p.mult(this.initialVel);
    if(t==1){
        this.applyForce(this.p);
    }
}



ParticleSystem.prototype.applyForce = function(f) {
    this.acc.add(f);
}


ParticleSystem.prototype.nu = function() {
    this.vel.add(this.acc);
    this.loc.add(this.vel);
    
    this.acc.mult(0);
    this.vel.limit(2);
    this.vel.mult(0.99);
    
    if(t%this.stepToMiss == 0 && this.loc.y<this.h){
        this.particles.push(new Particle(20, this.loc.y, this.columns, this.cor, this.index, this.intervalCells, this.finalPg, this.w, this.h, this.layer));
    }
    

    
}


/*
----------------------------------------------------------------
PARTICLE
----------------------------------------------------------------
*/


let Particle = function (x, y, tempColumns, tempCor, tempIndex, tempIntervalCells, tempPg, tempW, tempH, layer) {
    this.loc = createVector(0, y);
    this.vel = createVector(0, 0);
    this.acc = createVector(0, 0);

    this.columns = tempColumns;
    this.cor = tempCor;

    this.killingTime = 2.0;
    this.lifespan = 380.0;
    this.index = tempIndex;
    this.intervalCells = tempIntervalCells;

    this.finalPg = tempPg;
    this.w = tempW;
    this.h = tempH;

    this.step = (this.w)/this.columns;
    this.size = this.step/2-1;
    this.layer = layer;

    this.rrr = int(red(color(tempCor)));
    this.ggg = int(green(color(tempCor)));
    this.bbb = int(blue(color(tempCor)));
    
    this.randGlitchX = floor(random(2,4));
    this.randGlitchY = floor(random(1,2));
}


Particle.prototype.update = function() {
    this.sx = 0.0;
    this.sy = 0.0;

    this.acc = createVector(this.sx,this.sy);
    this.vel.add(this.acc);
    this.loc.add(this.vel);

    this.vel.limit(0.2);
    this.acc.mult(0);
    this.vel.mult(0.95);

    this.lifespan -= this.killingTime;


}


Particle.prototype.isDead = function () {
    if (this.lifespan <= 0.0) {
        return true;
    } else {
        return false;
    }
}


Particle.prototype.applyForce = function(f) {
    this.acc.add(f);
}


Particle.prototype.display = function() {


    for(let x=0; x<this.columns; x++){

        let finalX = x * int(this.step)+1;//floor(map(x, 0, this.columns-1, this.step/2, this.w-this.step/2));

        //if 2 columns
        if(x == 0){
            this.begin = -1;
            this.end = this.size*2;
        } else if(x == this.columns-1){
            this.begin = 0;
            this.end = this.size*2+3;
        }else{
            this.begin = 0;
            this.end = this.size*2;
        }

        //if 3 or 5 columns
        if(this.columns==3 || this.columns==5){
            if(x == this.columns-1){
                this.begin = 0;
                this.end = this.size*2+5;
            }
        }

        //if 6 columns
        if(this.columns==6){
            finalX = x * int(this.step)+3;

            if(x == this.columns-1){
                this.begin = 0;
                this.end = this.size*2+4;
            } else if(x == 0){
                this.begin = -3;
                this.end = this.size*2;
            } else {
                this.begin = 0;
                this.end = this.size*2;
            }
        }


        for(let i=this.begin; i<this.end; i++){
            let xx = int(finalX) + int(i);
            let yy = int(this.loc.y);
            
            //GLITCH AFTER 120 FRAMES
            if(t==120){
                this.randGlitchX = floor(random(1,4));
                this.randGlitchY = floor(random(1,4));
            }
            
            let index = int((xx + yy * this.w)*4);
            let index2 = (xx+1 + yy+3 * this.w)*4;
            let index3 = (xx + yy+10 * this.w)*4;
            let index4 = (xx+this.randGlitchX+10 + yy+this.randGlitchY * this.w)*4;
            
            
            

            //DEFINE ON A TEMP ARRAY
            if(this.lifespan>0){
            if((xx<finalImage.width/2-sizeCx/2-2 || xx>finalImage.width/2+sizeCx/2+1 || yy<finalImage.height/2-sizeCy/2 || yy>finalImage.height/2+sizeCy/2) && this.layer == 1){
                tempPixels[index] = this.rrr;
                tempPixels[index+1] = this.ggg;
                tempPixels[index+2] = this.bbb;
                tempPixels[index+3] = 255;
            }else if((xx>finalImage2.width/2-sizeCx/2-2 && xx<finalImage2.width/2+sizeCx/2+1 && yy>finalImage2.height/2-sizeCy/2 && yy<finalImage2.height/2+sizeCy/2) && this.layer == 2){
                tempPixels2[index] = this.rrr;
                tempPixels2[index+1] = this.ggg;
                tempPixels2[index+2] = this.bbb;
                tempPixels2[index+3] = 255;
                tempPixels2[index2] = this.rrr;
                tempPixels2[index2+1] = this.ggg;
                tempPixels2[index2+2] = this.bbb;
                tempPixels2[index2+3] = 255;
                tempPixels2[index4] = this.rrr;
                tempPixels2[index4+1] = this.ggg;
                tempPixels2[index4+2] = this.bbb;
                tempPixels2[index4+3] = 255;
            }
            }else{
                tempPixels[index] = 0;
                tempPixels[index+1] = 0;
                tempPixels[index+2] = 0;
                tempPixels[index+3] = 0;
                tempPixels2[index] = 0;
                tempPixels2[index+1] = 0;
                tempPixels2[index+2] = 0;
                tempPixels2[index+3] = 0;
                tempPixels2[index2] = 0;
                tempPixels2[index2+1] = 0;
                tempPixels2[index2+2] = 0;
                tempPixels2[index2+3] = 0;
                tempPixels2[index4] = 0;
                tempPixels2[index4+1] = 0;
                tempPixels2[index4+2] = 0;
                tempPixels2[index4+3] = 0;
            }


        }

    }
}




/////COMMANDS

function keyTyped() {

    ////PAUSE
    if (key === 'p') {
        running = !running;
    } else if(key === 's'){
        saveCanvas('gämma_' + nf(seed, 10, 0) + '.png');
    }
}

